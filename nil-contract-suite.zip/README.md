# NIL Contract Suite

Battle-tested starter suite for NIL transparency & compliance. Built as a Foundry project.

## Contracts

- `access/AccessControlRoles.sol` — central role definitions
- `interfaces/IComplianceRegistry.sol` — interface for compliance checks
- `ComplianceRegistry.sol` — KYC/AML/OFAC gates, token allowlists, state/country restrictions
- `DealNFT.sol` — ERC-721 that represents an NIL agreement; binds terms hash & participants
- `RevenueSplitter.sol` — deterministic payout splitter with tax withholding + compliance checks
- `NILVault.sol` — athlete-controlled vault with guardian + compliance-aware withdrawals
- `escrow/MilestoneEscrow.sol` — milestone-based escrow with dispute freeze
- `PayoutRouter.sol` — single-call payouts from brands through the registry
- `RestrictedVault.sol` — withdrawals only to pre-attested off-ramps for international use

## Tooling

- Foundry (forge/cast) for build, test, deploy
- OpenZeppelin contracts (install with `forge install OpenZeppelin/openzeppelin-contracts`)

## Quickstart

```bash
# from this folder
forge install OpenZeppelin/openzeppelin-contracts
forge build

# run tests (add your own in test/)
forge test -vv

# set env and deploy to a network
export RPC_URL="https://rpc.ankr.com/eth" # or base/sepolia/etc
export PRIVATE_KEY="0xabc..."              # dev key
forge script script/Deploy.s.sol:Deploy --rpc-url $RPC_URL --private-key $PRIVATE_KEY --broadcast
```

## Notes

- Compliance logic is modular — you can swap `ComplianceRegistry` for an oracle-backed version.
- All sensitive actions are pausable and role-gated. Use a multisig for `DEFAULT_ADMIN_ROLE`.
- This is engineering guidance, not legal advice. Get counsel before production changes.
