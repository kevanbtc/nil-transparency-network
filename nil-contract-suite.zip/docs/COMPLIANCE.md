# Compliance Model (Engineering View)

This suite *enforces* compliance decisions — it does not *make* them. Upstream signals feed `ComplianceRegistry`:
- **KYC attestation** (pass/fail, age if needed)
- **Sanctions** (OFAC/EU/UK/UN)
- **Jurisdiction** (ISO-3166 country and US state code)
- **Token allowlist** (stablecoins only by default)
- **Deal approval** (per-NIL agreement)

Recommended adapters:
- **EAS (Ethereum Attestation Service)** for KYC/age attestations
- **Chainlink** or **custom oracle** for sanctions lists and token allowlist updates
- **TRM/Chainalysis** off-chain with signed updates via `ORACLE_ROLE`

### NCAA & NIL Considerations

- Route all brand -> athlete payments through an **approved deal** (DealNFT + `dealId`)
- University/arbiter approves milestone releases (`MilestoneEscrow`)
- Enforce **no pay-for-play** via deal metadata policies (off-chain review -> `setDealApproved`)
- Use **splitter withholding** for taxes and program fees
- Keep **immutable audit trail** via on-chain events; mirror to off-chain logs for ISO 20022 payloads

### Global Reach

- Restrict tokens via allowlist (USDC/USDT per chain)
- Use `RestrictedVault` for international athletes with controlled off-ramps
- Maintain **Pillar 2 AML** controls via sanctions/KYC gate + transaction limits (enforced off-chain, checked on-chain via `LimitExceeded` if needed)
