# Frontend Publish/Preview Fixes (Vite + GitHub Pages/Vercel)

1) **Vite base path** (GitHub Pages):
```ts
// vite.config.ts
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  base: '/nil-transparency-net/', // <-- repo name
})
```

2) **SPA Fallback** (GitHub Pages): add `404.html` that mirrors `index.html` content so deep links work.
```bash
cp dist/index.html dist/404.html
```

3) **GitHub Action** for Pages:
```yaml
# .github/workflows/deploy.yml
name: Deploy
on:
  push:
    branches: [ main ]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: {{ node-version: '18' }}
      - run: npm ci
      - run: npm run build
      - uses: actions/upload-pages-artifact@v3
        with: { path: 'dist' }
  deploy:
    needs: build
    permissions:
      pages: write
      id-token: write
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    steps:
      - id: deployment
        uses: actions/deploy-pages@v4
```

4) **Vercel**:
- Create `vercel.json` in repo root:
```json
{ "buildCommand": "npm run build", "outputDirectory": "dist", "rewrites": [{ "source": "/(.*)", "destination": "/" }] }
```
- Ensure Project Settings → Framework: Vite, Output: `dist`.

5) **Local preview**:
```
npm run build && npm run preview
# visit the URL printed by Vite (usually http://localhost:4173)
```
