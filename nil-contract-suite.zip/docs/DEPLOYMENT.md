# Deployment & Verification

## Prereqs
- Foundry installed
- Admin multisig address ready
- Athlete address(es)
- RPC URL + funded deployer

## Install deps
```
forge install OpenZeppelin/openzeppelin-contracts
forge build
```

## Deploy
```
export ADMIN=0xYourMultisig
export ATHLETE=0xAthleteAddress
export RPC_URL=https://sepolia.base.org
export PRIVATE_KEY=0xabc...

forge script script/Deploy.s.sol:Deploy --rpc-url $RPC_URL --private-key $PRIVATE_KEY --broadcast
```

## Post-Deploy
- Grant roles:
  - `COMPLIANCE_ROLE` to your compliance ops multisig
  - `ORACLE_ROLE` to oracle updater(s)
  - `BRAND_ROLE` to brand payment senders
  - `UNIVERSITY_ROLE` to school accounts
- Allow tokens via `setTokenAllowed(token, true)`
- Seed parties via `setParty(address, Party{...})`
- Approve deals via `setDealApproved(dealId, true)`
